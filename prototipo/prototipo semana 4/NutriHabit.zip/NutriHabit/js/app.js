function guardarConsumo(){

    const cantidad =
    document.getElementById("cantidad").value;

    if(cantidad === ""){
        alert("Ingrese una cantidad");
        return;
    }

    alert(
        "Consumo registrado correctamente: "
        + cantidad +
        " ml"
    );

    window.location.href = "index.html";
}